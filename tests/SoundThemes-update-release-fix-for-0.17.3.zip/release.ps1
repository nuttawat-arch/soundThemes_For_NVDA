# Local-only Sound Themes release automation for Windows PowerShell 5.1+.
# Never distribute this script: .gitignore and build_source.py both exclude it.
# Usage: powershell -ExecutionPolicy Bypass -File .\release.ps1 -Version 0.17.0
#        powershell -ExecutionPolicy Bypass -File .\release.ps1   # increment patch
#        powershell -ExecutionPolicy Bypass -File .\release.ps1 -DryRun

[CmdletBinding()]
param(
    [string]$Version = '',
    [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$repoRoot = $PSScriptRoot
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

function Require-Success {
    param([string]$Command, [string[]]$Arguments)
    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Failed (exit $LASTEXITCODE): $Command $($Arguments -join ' ')"
    }
}

function Update-Heading {
    param([string]$RelativePath, [string]$Pattern, [string]$NewHeading)
    $path = Join-Path $repoRoot $RelativePath
    $original = [System.IO.File]::ReadAllText($path)
    $regex = [System.Text.RegularExpressions.Regex]::new($Pattern, [System.Text.RegularExpressions.RegexOptions]::Multiline)
    if (-not $regex.IsMatch($original)) { throw "Version heading not found in $RelativePath" }
    $updated = $regex.Replace($original, $NewHeading, 1)
    [System.IO.File]::WriteAllText($path, $updated, $utf8NoBom)
}

function Get-GitHubApi {
    param([string]$Url)
    $headers = @{
        'User-Agent' = 'SoundThemesForNVDA-release-script'
        'Accept' = 'application/vnd.github+json'
        'Cache-Control' = 'no-cache'
    }
    Invoke-RestMethod -Method Get -Uri $Url -Headers $headers -TimeoutSec 20 -ErrorAction Stop
}

function Wait-ForPublishedRelease {
    param([string]$Tag, [string]$Version)
    $apiBase = 'https://api.github.com/repos/nuttawat-arch/soundThemes_For_NVDA'
    $expectedAsset = "SoundThemesForNVDA-$Version.nvda-addon"
    $deadline = [DateTime]::UtcNow.AddMinutes(8)
    $attempt = 0
    Write-Host "Waiting for GitHub Actions and the downloadable $Tag Release (up to 8 minutes)..."

    while ([DateTime]::UtcNow -lt $deadline) {
        $attempt++
        try {
            $published = Get-GitHubApi "$apiBase/releases/tags/$Tag"
            $assets = @($published.assets | Where-Object {
                $_.name -eq $expectedAsset -and [int64]$_.size -gt 0
            })
            if (-not $published.draft -and -not $published.prerelease -and $assets.Count -gt 0) {
                $latest = Get-GitHubApi "$apiBase/releases/latest"
                if ($latest.tag_name -eq $Tag) {
                    Write-Host "Verified: $Tag is the latest published Release and its installer is available."
                    return
                }
            }
        } catch {
            # Before publication, the tag's Releases API endpoint returns HTTP 404.
            # Other transient API failures are retried until the deadline.
            if (-not $_.Exception.Response -or [int]$_.Exception.Response.StatusCode -ne 404) {
                Write-Warning "GitHub Release check will retry: $($_.Exception.Message)"
            }
        }

        if ($attempt % 3 -eq 0) {
            try {
                $runs = Get-GitHubApi "$apiBase/actions/runs?event=push&per_page=20"
                $tagRun = $runs.workflow_runs | Where-Object {
                    $_.head_branch -eq $Tag -and $_.event -eq 'push'
                } | Select-Object -First 1
                if ($tagRun -and $tagRun.status -eq 'completed' -and $tagRun.conclusion -ne 'success') {
                    throw "GitHub Actions failed for $Tag. Open $($tagRun.html_url) to inspect the failed step."
                }
            } catch {
                if ($_.Exception.Message -like 'GitHub Actions failed for *') { throw }
                Write-Warning "GitHub Actions check will retry: $($_.Exception.Message)"
            }
        }
        Start-Sleep -Seconds 15
    }

    throw "Pushed $Tag, but GitHub has not published a downloadable latest Release within 8 minutes. Check https://github.com/nuttawat-arch/soundThemes_For_NVDA/actions before announcing the update."
}

Push-Location $repoRoot
try {
    $manifest = Join-Path $repoRoot 'manifest.ini'
    $originalManifest = [System.IO.File]::ReadAllText($manifest)
    $match = [regex]::Match($originalManifest, '(?m)^version[ \t]*=[ \t]*"(\d+)\.(\d+)\.(\d+)"[ \t]*\r?$')
    if (-not $match.Success) { throw 'Cannot read the add-on version in manifest.ini' }
    $current = "$($match.Groups[1].Value).$($match.Groups[2].Value).$($match.Groups[3].Value)"
    if (-not $Version) {
        $nextPatch = [int]$match.Groups[3].Value + 1
        $Version = "$($match.Groups[1].Value).$($match.Groups[2].Value).$nextPatch"
    }
    if ($Version -notmatch '^\d+\.\d+\.\d+$') { throw 'Provide a version such as 0.15.0.' }
    $tag = "v$Version"
    if ($DryRun) {
        Write-Host "Dry run: $current -> $Version; would test, build, commit, push main and push $tag."
        Write-Host 'The local release.ps1 remains excluded from Git and source ZIP.'
        return
    }

    Require-Success 'git' @('rev-parse', '--is-inside-work-tree')
    $actualRoot = (& git rev-parse --show-toplevel).Trim()
    if ($LASTEXITCODE -ne 0 -or
        [System.IO.Path]::GetFullPath($actualRoot) -ne [System.IO.Path]::GetFullPath($repoRoot)) {
        throw 'Run release.ps1 inside your existing Sound Themes Git repository root.'
    }
    $branch = (& git branch --show-current).Trim()
    if ($branch -ne 'main') { throw "Release must run from branch main (current: $branch)" }
    $remote = (& git remote get-url origin).Trim()
    if ($LASTEXITCODE -ne 0 -or $remote -notmatch 'github\.com[:/]nuttawat-arch/soundThemes_For_NVDA(?:\.git)?$') {
        throw 'The origin Git remote is not the expected Sound Themes GitHub repository.'
    }
    $trackedScript = & git ls-files -- release.ps1
    if ($trackedScript) {
        throw 'release.ps1 is tracked! Remove it from the Git index before releasing (keep the local file).'
    }
    if (& git tag --list $tag) { throw "Local tag $tag already exists; never replace a release tag." }

    Write-Host 'Checking remote branch and tags...'
    Require-Success 'git' @('fetch', 'origin', 'main')
    $behind = (& git rev-list --count 'HEAD..origin/main').Trim()
    if ($LASTEXITCODE -ne 0 -or [int]$behind -ne 0) {
        throw 'Remote main has newer commits. Sync with git pull --ff-only origin main first.'
    }
    $remoteTag = & git ls-remote --tags origin "refs/tags/$tag"
    if ($LASTEXITCODE -ne 0) { throw 'Cannot check remote tags on GitHub.' }
    if ($remoteTag) { throw "Remote tag $tag already exists; never overwrite it." }

    Write-Host 'Running all offline tests before publishing...'
    Require-Success 'python' @('-B', '-m', 'unittest', 'discover', '-s', 'tests', '-q')

    if ($Version -ne $current) {
        Update-Heading 'manifest.ini' '^version[ \t]*=[ \t]*"\d+\.\d+\.\d+"[ \t]*\r?$' "version = `"$Version`""
        Update-Heading 'README.md' '^# Sound Themes for NVDA \d+\.\d+\.\d+$' "# Sound Themes for NVDA $Version"
        Update-Heading 'PROJECT_STATUS.md' '^# Sound Themes for NVDA — Project status v\d+\.\d+\.\d+ \(' "# Sound Themes for NVDA — Project status v$Version ("
        Update-Heading 'KEYBOARD_SOUNDS_GUIDE.md' '^# Sound Themes for NVDA — Keyboard Sounds \(v\d+\.\d+\.\d+\)' "# Sound Themes for NVDA — Keyboard Sounds (v$Version)"
        Update-Heading 'SOUND_SOURCES.md' '^# Sound provenance and merger status — v\d+\.\d+\.\d+ \(' "# Sound provenance and merger status — v$Version ("
        Update-Heading 'doc/en/readme.html' '<p>Version \d+\.\d+\.\d+\.' "<p>Version $Version."
        Update-Heading 'doc/th/readme.html' '<p>เวอร์ชัน \d+\.\d+\.\d+' "<p>เวอร์ชัน $Version"
    }

    Write-Host "Building Sound Themes $Version..."
    Require-Success 'python' @('scripts/build.py')
    Require-Success 'python' @('scripts/build_source.py')
    $addon = Join-Path $repoRoot "SoundThemesForNVDA-$Version.nvda-addon"
    $source = Join-Path (Split-Path $repoRoot -Parent) "SoundThemesForNVDA-source-$Version.zip"
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    foreach ($archivePath in @($addon, $source)) {
        $archive = [System.IO.Compression.ZipFile]::OpenRead($archivePath)
        try {
            if ($archive.Entries.Count -lt 100) { throw "Incomplete ZIP: $archivePath" }
            if (@($archive.Entries | Where-Object { $_.FullName -match '(^|/)release\.ps1$' }).Count) {
                throw "Private release.ps1 unexpectedly included in $archivePath"
            }
        } finally { $archive.Dispose() }
    }

    Require-Success 'git' @('add', '-A')
    $staged = @(& git diff --cached --name-only)
    if ($LASTEXITCODE -ne 0 -or @($staged | Where-Object { $_ -match '(^|/)release\.ps1$' }).Count) {
        throw 'Private release.ps1 is staged; release stopped before commit.'
    }
    if ($staged.Count -eq 0) { throw 'No changes staged. Release needs a new version or code changes.' }

    Require-Success 'git' @('-c', 'user.name=Nuttawat Seecham', '-c', 'user.email=nutblind2545t@gmail.com',
        'commit', '-m', "Release Sound Themes for NVDA $Version")
    Require-Success 'git' @('push', 'origin', 'main')
    Require-Success 'git' @('tag', $tag)
    Require-Success 'git' @('push', 'origin', $tag)
    Write-Host "Pushed main and $tag. Waiting for the release to finish publishing..."
    Wait-ForPublishedRelease -Tag $tag -Version $Version
    Write-Host "Success: GitHub Release $tag is published, verified and ready for NVDA updates."
    Write-Host "Release: https://github.com/nuttawat-arch/soundThemes_For_NVDA/releases/tag/$tag"
    Write-Host 'No NVDA Add-on Store submission was made.'
} finally {
    Pop-Location
}
